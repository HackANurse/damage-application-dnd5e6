# Attribution and provenance

This package is a modification of **Damage Application 11.2.0** by Zhell (krbz999). The original project used the MIT License, copyright © 2023 Zhell. Its full license and copyright notice are preserved unchanged in `LICENSE`.

Original project: https://github.com/krbz999/damage-application

Archived 11.2.0 source: https://archive.softwareheritage.org/browse/snapshot/0ea5ea4d4bc4286b94e01f2a791919ad2c7390b5/

The compatibility changes adapt message detection and damage aggregation, saving throws, damage application options, chat rendering, token ring effects, and the module manifest for Foundry 14 and dnd5e 6.0.6 through 6.1.0. The 6.1.0 update also passes chat message damage rules through to the actor when applying damage. The CSS, Handlebars templates, and English localization remain unchanged from the 11.2.0 release.

This is an independent compatibility fork published by HackANurse. It is not an official update or an endorsement by the original author. Any funding link added to this fork supports this version and does not represent the original author.

This project is solely an independent add-on module for Foundry Virtual Tabletop and its dnd5e game system. It is not associated with, affiliated with, sponsored by, or endorsed by Foundry Virtual Tabletop, the dnd5e game system team, or Wizards of the Coast.
