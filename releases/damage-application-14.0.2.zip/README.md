# Damage Application — dnd5e 6 compatibility fork

A compatibility update of [Zhell's Damage Application](https://github.com/krbz999/damage-application) module, based on release **11.2.0**. It targets **Foundry VTT 14** and **dnd5e 6.0.6 through 6.1.0**. This fork is independent of the original maintainer.

The module adds controls to damage and healing chat messages for applying damage, half damage, healing, and temporary HP to selected tokens. GMs can open a dialog to adjust damage types, toggle relevant damage traits, and roll saving throws before applying damage.

## Independent add-on

This project is solely an independent add-on module for Foundry Virtual Tabletop and its dnd5e game system. It is not associated with, affiliated with, sponsored by, or endorsed by Foundry Virtual Tabletop, the dnd5e game system team, or Wizards of the Coast.

## Status

The code has been checked against the dnd5e 6.0.6 and 6.1.0 source APIs for Foundry 14. Local automated checks cover damage message data, saving throws, damage options, the 6.1.0 chat message damage rules, and the “no damage on a successful save” case. A user tested the 6.0.6 fork in Foundry and reported that it works. The 6.1.0 update has not yet been tested in a live Foundry world.

## Install

The 14.0.2 package is currently available as a local ZIP in `releases/`. Extract its contents into `Data/modules/damage-application/`, then restart Foundry. This fork uses the original module ID, so it replaces the original installation and cannot run alongside it.

After publishing 14.0.2 to the repository, you can also open **Add-on Modules → Install Module** in Foundry VTT, paste this URL into **Manifest URL**, and install:

```text
https://raw.githubusercontent.com/HackANurse/damage-application-dnd5e6/main/module.json
```

The [versioned ZIP URL](https://raw.githubusercontent.com/HackANurse/damage-application-dnd5e6/main/releases/damage-application-14.0.2.zip) will work after the new package is published.

## Source and updates

The source for this fork is at [HackANurse/damage-application-dnd5e6](https://github.com/HackANurse/damage-application-dnd5e6). The root `module.json` is the stable manifest URL for installation and update checks. Its `download` field points to a versioned ZIP stored in `releases/`. Keep `LICENSE` and `NOTICE.md` with any redistributed copy.

Run the checks with:

```sh
node --test tests/compat.test.mjs
node --check module/module.mjs
```

## Credits and license

Original code, styles, templates, and English localization: **Zhell (krbz999)**, © 2023, under the MIT License. Compatibility fork: **HackANurse**. The unmodified original license text is included in [LICENSE](LICENSE). See [NOTICE.md](NOTICE.md) for provenance and changes. This repository does not bundle Foundry or dnd5e source code or third-party artwork.

## Support this fork

You can [support HackANurse's compatibility fork on Buy Me a Coffee](https://buymeacoffee.com/andybegh). This link supports the maintenance of this independent fork; it does not represent the original author.
